/**
 * @author Ariel Guerrero
 */

package application.model;

public class Dinosaur {

    private String name = "", type = "";
    private Boolean isHerbavore = null;
    private Zone currentZone = null;
    private String diet ="";

    public Dinosaur(String name, String type, Boolean isHerbavore, Zone currentZone) {
        this.name = name;
        this.type = type;
        this.isHerbavore = isHerbavore;
        this.currentZone = currentZone;
        setDiet(isHerbavore);
    }

    public String getDiet() {
        return diet;
    }

    public String getName() {
        return name;
    }

    public Boolean getHerbavore() {
        return isHerbavore;
    }

    public String getType() {
        return type;
    }

    public Zone getCurrentZone() {
        return currentZone;
    }

    public void setDiet(String diet) {
        this.diet = diet;
    }

    public void setDiet(Boolean isHerbavore) {
        setDiet("Herbavore");
        if(!isHerbavore)
            setDiet( "Carnivore");
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCurrentZone(Zone currentZone) {
        this.currentZone = currentZone;
    }

    public void setHerbavore(Boolean isHerbavore) {
        this.isHerbavore = isHerbavore;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() { return  getName() + " - " + getType() + " - " + getDiet(); }
}
